let word = [
    "shrek",
    "fiona",
    "farquaad",
    "donkey",
    "donald trump",
    "whatever"
];
let failedWord = [];

winArray = [];
function randomizer () {
   local = word[Math.floor(Math.random()*word.length)];
   
    randomWord = local.split("");
    
   console.log(randomWord);
}

function toggleSpan () {
    for (i = 0; i < randomWord.length; i++) {
      let  variable= document.getElementById("pid");
        variable.innerHTML += "<span>" + randomWord[i] + "</span>";
        
    }
}
randomizer();

toggleSpan();
function win () {
   console.log(randomWord);
   if (randomWord.length === winArray.length) {
       document.querySelector("#winoverlay").classList.add("overlay");
       
   }
}



let counter = 1;

function lost() {
    temp = randomWord.join("");
    document.querySelector("#overlay").classList.add("overlay");
    document.getElementById("correctword").innerHTML = "Correct word:" + temp;
    

  
}



function showHanged() {
 
    if (counter === 1) {
        document.querySelector("figure").classList.add("scaffold");
        
    } 
    if (counter === 2) {
        document.querySelector("figure").classList.add("head");
       
    }

    if (counter === 3) {
        document.querySelector("figure").classList.add("body");
       
    }

    if (counter ===4 ) {
        document.querySelector("figure").classList.add("arms");
        
    }

    if (counter === 5) {
        document.querySelector("figure").classList.add("legs");
        
        lost();
        
    }   



   
}

function countingFails (value) {
    if (failedWord.includes(value)===true) {
        
    } else {
        failedWord.push(value);
        showHanged();
        counter += 1;
        
    }
    
}
holder = [];

function toggleClass (value) {
    let spans = document.querySelectorAll("span");
   
    for (span of spans) {
      
        spanValue = span.innerText;
        if (value === spanValue) {
           span.classList.add("show");
           if (spanValue.includes(value)=== true) {
           
            winArray.push(value);
            console.log(winArray);
           } 
           
           
        }

    }

}

function compare(value) {
    if (randomWord.includes(value) === true && winArray.includes(value) === false ) {
        toggleClass(value);
        win();
    } else {
        countingFails(value);
        
        console.log(counter);
        console.log(failedWord);
    }
  
  
}


window.addEventListener("keypress", function(event) {
    const  value = event.key;
    if (counter < 6 ) {
        compare(value);
    }
    
   
    
  
   
})

